/*
 * Simple base Raflie
 * Not delete cresdits
 * © Rafliee Modss
*/

//---------#Ex Isi File#
const fs = require("fs") 

        // ~Settings Bot~ //
//<><><><><><><><><><><<><><><><><//
global.owner = "6285123965478"
global.ownername = "RaflieeeModsss"
global.botname = "SimpelBase"
global.versionsc = "1"
global.author = "RAFLIE MODS\n\n"
global.title = "sɪᴍᴘʟᴇ ʙᴀsᴇ\n• ʀᴀғʟɪᴇ ᴍᴏᴅs"
global.body = "ʀᴀғʟɪᴇ ᴍᴏᴅs"
global.footer = "RaflieVx"
global.packname = "Raflieeee"
global.webmenu = "https://"
global.session = "sessions"

global.image = {
Qphoto: "https://files.catbox.moe/towz6u.jpg", 
Xreply: "https://files.catbox.moe/towz6u.jpg"
}

global.Newsletter = {
Name: "!- Rafliiee Ryuchi", 
idChannel: "120363400321589684@newsletter"
}

global.socialMedia = {
YouTube: "https://youtube.com/@RaflieModss",
GitHub: "https://github.com/RaflieDev",
Telegram: "https://t.me/rafzzztzyy",
ChannelWA: "https://whatsapp.com/channel/0029VbCaritJkK73qfHPBb3Y"
}

global.betonText = {
Button1: "Owner", 
Button2: "Show All Menu"
}

global.emojiX = {
EmojiX1: "🚀", 
EmojiX2: "☑️", 
EmojiX3: "⚡"
}

global.status = {
Public: true
}

       // -!s Raflie Modsss //
      // ~Prubahan Isi File~ //
//<><><><><><><><><><><<><><><><><//
let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})

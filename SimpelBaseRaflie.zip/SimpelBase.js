/*
 -! Created base By Raflie Mods
 * Simple base Raflie
 * Not delete cresdits
 * © Rafliee Modss
*/

require('./settings');

//------------------⧼ IMPORT MODULE ⧽
const fs = require('fs');
const axios = require('axios');
const path = require('path');
const crypto = require("crypto");
const chalk = require("chalk");
const { Client } = require('ssh2');
const util = require("util");
const moment = require("moment-timezone");
const { spawn, exec, execSync } = require('child_process');
const JsConfuser = require('js-confuser');

//------------------⧼ IMPORT MODULE UPLOADER ⧽
const { 
  TelegraPh, 
  UploadFileUgu, 
  webp2mp4File, 
  floNime
} = require('./lib/uploader')

//------------------⧼ DEFAULT IMPORT MODULE ⧽
const { 
  default: baileys, 
  proto, 
  generateWAMessage, 
  generateWAMessageFromContent, 
  getContentType, 
  prepareWAMessageMedia
} = require("@whiskeysockets/baileys");

module.exports = Raflie = async (Raflie, m, chatUpdate, store) => {
try {
const body = (
m.mtype === "conversation" ? m.message.conversation :
m.mtype === "imageMessage" ? m.message.imageMessage.caption :
m.mtype === "videoMessage" ? m.message.videoMessage.caption :
m.mtype === "extendedTextMessage" ? m.message.extendedTextMessage.text :
m.mtype === "buttonsResponseMessage" ? m.message.buttonsResponseMessage.selectedButtonId :
m.mtype === "listResponseMessage" ? m.message.listResponseMessage.singleSelectReply.selectedRowId :
m.mtype === "templateButtonReplyMessage" ? m.message.templateButtonReplyMessage.selectedId :
m.mtype === "interactiveResponseMessage" ? JSON.parse(m.msg.nativeFlowResponseMessage.paramsJson).id :
m.mtype === "templateButtonReplyMessage" ? m.msg.selectedId :
m.mtype === "messageContextInfo" ? m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text : ""
);

//-----------------⧼  Sender ⧽
const sender = m.key.fromMe
? Raflie.user.id.split(":")[0] || Raflie.user.id
: m.key.participant || m.key.remoteJid;
const senderNumber = sender.split('@')[0];

//------------------⧼ Database ⧽
const owner = JSON.parse(fs.readFileSync('./Database/owner.json'));
const premium = JSON.parse(fs.readFileSync('./Database/premium.json'));
const botNumber = await Raflie.decodeJid(Raflie.user.id);
const isBot = botNumber.includes(senderNumber)
const isPremium = premium.includes(sender)
const isOwner = [botNumber, ...owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
const dev = JSON.parse(fs.readFileSync('./Database/developer.json'));
const isDev = [botNumber, ...dev].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)

//------------------⧼ Command ⧽
const command = body.slice(1).trim().split(/ +/).shift().toLowerCase();
const budy = (typeof m.text === 'string' ? m.text : '');
const prefa = ["", "!", ".", ",", "🐤", "🗿"];
const prefix = /^[°zZ#$@+,.?=''():√%!¢£¥€π¤ΠΦ&><™©®Δ^βα¦|/\\©^]/.test(body) ? body.match(/^[°zZ#$@+,.?=''():√%¢£¥€π¤ΠΦ&><!™©®Δ^βα¦|/\\©^]/gi) : '.';

//------------------⧼ Xc Fungsi ⧽
const args = body.trim().split(/ +/).slice(1);
const pushname = m.pushName || "No Name";
const text = q = args.join(" ");
const quoted = m.quoted ? m.quoted : m;
const mime = (quoted.msg || quoted).mimetype || '';
const qmsg = (quoted.msg || quoted);
const isMedia = /image|video|sticker|audio/.test(mime);
const from = m.key.remoteJid;
const isGroup = from.endsWith("@g.us");
//------------------⧼ Group Fungsi ⧽
        const groupMetadata = isGroup ? await Raflie.groupMetadata(m.chat).catch(() => {}) : '';
        const groupOwner = isGroup && groupMetadata ? groupMetadata.owner : '';
        const groupName = isGroup && groupMetadata && groupMetadata.subject ? groupMetadata.subject : '';
        const participants = isGroup && groupMetadata && groupMetadata.participants ? groupMetadata.participants : [];
        const groupAdmins = isGroup ? participants.filter(v => v.admin !== null).map(v => v.id) : [];
        const isGroupAdmins = isGroup ? groupAdmins.includes(sender) : false;
        const isBotGroupAdmins = isGroup ? groupAdmins.includes(botNumber) : false;
        const isAdmins = isGroup ? groupAdmins.includes(sender) : false;


//------------------⧼ Is Function ⧽
const { 
  smsg, 
  sendGmail, 
  formatSize, 
  isUrl, 
  generateMessageTag, 
  getBuffer, 
  getSizeMedia, 
  runtime, 
  fetchJson, 
  resize, 
  sleep
} = require('./lib/myfunction');



//------------------⧼ Waktu & Ucapan ⧽
const time = moment(Date.now()).tz('Asia/Jakarta').locale('id').format('HH:mm:ss z')
const xtime = moment().tz('Asia/Jakarta').format('HH:mm:ss');
const date = moment.tz('Asia/Jakarta').format('DD MMMM YYYY')
const time2 = moment().tz('Asia/Kolkata').format('HH:mm:ss');
let ucapanWaktu
if (time >= "19:00:00" && time < "23:59:00") {
ucapanWaktu = "🌃 Good Night"
} else if (time >= "15:00:00" && time < "19:00:00") {
ucapanWaktu = "🌄 Good Evening"
} else if (time >= "11:00:00" && time < "15:00:00") {
ucapanWaktu = "🏞️ Good Afternoon"
} else if (time >= "06:00:00" && time < "11:00:00") {
ucapanWaktu = "🏙️ Good Morning"
} else {
ucapanWaktu = "🌆 Early Morning"
}




// ------------------ Console log / terminal 
if (m.message) {
console.log('\x1b[30m--------------------\x1b[0m');
console.log(chalk.bgHex("#e74c3c").bold(`➤ New Messages`));
console.log(
chalk.bgHex("#00FF00").black(
` ╭─ > Tanggal: ${new Date().toLocaleString()} \n` +
` ├─ > Pesan: ${m.body || m.mtype} \n` +
` ├─ > Pengirim: ${m.pushname} \n` +
` ╰─ > JID: ${senderNumber}`
)
);
if (m.isGroup) {
console.log(
chalk.bgHex("#00FF00").black(
` ╭─ > Grup: ${groupName} \n` +
` ╰─ > GroupJid: ${m.chat}`
)
);
}
console.log();
}


//---------------------⧼ GetFile ⧽
function getFileTypeFromUrl(url) {
const parts = url.split('.');
return parts[parts.length - 1];
}    

//---------------------⧼ pickRandom ⧽
function pickRandom(list) {
return list[Math.floor(Math.random() * list.length)]; }

//----------------------⧼ Random React  ⧽
const emoji = [ '⚡', '💫', '⭐', '🌟', '✨', '🔥', '✅', '🍃', '☘️', '🐉', '📥', '🚀' ];
const RandomReact = emoji[Math.floor(Math.random() * emoji.length)];

//----------------------⧼ Reply && Xquoted ⧽ 
        
async function rafzreply(text) {
Raflie.sendMessage(m.chat, {
text: "\n" + text + "\n",
contextInfo: {
mentionedJid: [sender],
externalAdReply: {
title: title,
body: body,
thumbnailUrl: global.image.Xreply,
sourceUrl: global.socialMedia.Telegram,
renderLargerThumbnail: false,
}
}
}, { quoted: qxc })
}

const qxc = {
key: {
fromMe: false,
participant: "0@s.whatsapp.net",
remoteJid: "120363400662819774@g.us"
},
message: {
orderMessage: {
orderId: "9999",
thumbnail: "",
itemCount: "9999",
status: "INQUIRY",
surface: "CATALOG",
message: `√ Simple Base\n• Raflie Modss`,
token: "AR6xBKbXZn0Xwmu76Ksyd7rnxI+Rx87HfinVlW4lwXa6JA==", 
contextInfo: {
mentionedJid: ["0@s.whatsapp.net"],
forwardingScore: 999,
isForwarded: true
}
}
}
}




//------------------⧼ Menu ⧽
switch (command) {
case "menu": {
await Raflie.sendMessage(m.chat, { react: { text: RandomReact, key: m.key, }})
let captionX = `
${ucapanWaktu}
√ Simple Base\n• Raflie Mods - 2025`
await Raflie.sendMessage(m.chat, {
image: { url: 'https://files.catbox.moe/towz6u.jpg' },
caption: captionX,
footer: `√ Simple Base\n• Raflie Mods`,
quoted: qxc
});
}
break;

case "self": {
if (!isOwner) return rafzreply("*[ Owner Akses Not For Free User! ]*\n√ sɪᴍᴘʟᴇ ʙᴀsᴇ\n• ʀᴀғʟɪᴇ ᴍᴏᴅs") 
Raflie.public = false 
rafzreply("*[ Sukses Self Mode Sekarang Bot Mu Tidak Dapat Di Akses Orang Lain ]*\n√ sɪᴍᴘʟᴇ ʙᴀsᴇ\n• ʀᴀғʟɪᴇ ᴍᴏᴅs") 
}
break;

case "public": {
if (!isOwner) return rafzreply("*[ Owner Akses Not For Free User! ]*\n√ sɪᴍᴘʟᴇ ʙᴀsᴇ\n• ʀᴀғʟɪᴇ ᴍᴏᴅs") 
Raflie.public = true
rafzreply("*[ Sukses Public Mode Sekarang Bot Mu Dapat Di Akses Semua Orang ]*\n√ sɪᴍᴘʟᴇ ʙᴀsᴇ\n• ʀᴀғʟɪᴇ ᴍᴏᴅs") 
}
break;


//------------------⧼ Akhir Dari Fitur ⧽
default:
if (budy.startsWith('>')) {
if (!isDev) return;
try {
let evaled = await eval(budy.slice(2));
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled);
await rafzreply(evaled);
} catch (err) {
rafzreply(String(err));
}
}
if (budy.startsWith('$') || budy.startsWith('=>') || budy.startsWith('<')) {
  if (!isDev) return;
  let kode = budy.slice(budy.startsWith('$') ? 1 : 2).trim()
  if (budy.startsWith('$')) {
    const { exec } = require('child_process')
    exec(kode, (err, stdout, stderr) => {
      if (err) return rafzreply(`Error: ${err}`)
      if (stderr) return rafzreply(`stderr: ${stderr}`)
      rafzreply(stdout)
    })
  } else {
    try {
      let teks = await eval(`(async () => { ${budy.startsWith('=>') ? "return" : ""} ${kode}})()`)
      await rafzreply(require('util').format(teks))
    } catch (e) {
      await rafzreply(require('util').format(e))
    }
  }
}

}
} catch (err) {
console.log(require("util").format(err));
}
};

let file = require.resolve(__filename);
require('fs').watchFile(file, () => {
require('fs').unwatchFile(file);
console.log('\x1b[0;32m' + __filename + ' \x1b[1;32mupdated!\x1b[0m');
delete require.cache[file];
require(file);
});